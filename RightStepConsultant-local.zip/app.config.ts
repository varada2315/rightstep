export default {
  logoUrl: "https://cdn.jsdelivr.net/gh/lucide-static/lucide/icons/globe.svg"
}
