import React, { useEffect, useState } from 'react'
import { createRoot } from 'react-dom/client'
import { ArrowRight, ArrowUpRight, Check, Globe2, Menu, MessageCircle, Phone, Plane, ShieldCheck, Star, X } from 'lucide-react'
import './styles.css'

const PHONE = '9148020482'
const EMAIL = 'admin@rightstepconsultant.com'
const WHATSAPP = 'https://wa.me/919148020482'
const navItems = [
  { id: 'home', label: 'Home' },
  { id: 'immigration', label: 'Immigration' },
  { id: 'countries', label: 'Countries' },
  { id: 'education', label: 'Education' },
  { id: 'about', label: 'About us' },
]

const countries = [
  { code: 'CA', name: 'Canada', type: 'Study · Work · Settle' },
  { code: 'AU', name: 'Australia', type: 'Study · Skilled work' },
  { code: 'GB', name: 'United Kingdom', type: 'Study · Graduate routes' },
  { code: 'DE', name: 'Germany', type: 'Study · Opportunity card' },
]

function App() {
  const [activeSection, setActiveSection] = useState('home')
  const [menuOpen, setMenuOpen] = useState(false)
  const [modal, setModal] = useState(null)
  const [toast, setToast] = useState('')

  useEffect(() => {
    const sections = navItems.map(({ id }) => document.getElementById(id)).filter(Boolean)
    const observer = new IntersectionObserver((entries) => {
      const visible = entries.filter((entry) => entry.isIntersecting).sort((a, b) => b.intersectionRatio - a.intersectionRatio)
      if (visible[0]) setActiveSection(visible[0].target.id)
    }, { rootMargin: '-22% 0px -60% 0px', threshold: [0.05, 0.2, 0.4] })
    sections.forEach((section) => observer.observe(section))
    return () => observer.disconnect()
  }, [])

  useEffect(() => {
    document.body.style.overflow = modal ? 'hidden' : ''
    return () => { document.body.style.overflow = '' }
  }, [modal])

  const scrollTo = (id) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' })
    setMenuOpen(false)
  }

  const handleApply = (event) => {
    event.preventDefault()
    const data = new FormData(event.currentTarget)
    const name = data.get('name') || 'there'
    const interest = data.get('interest') || 'international opportunities'
    const subject = encodeURIComponent(`Application enquiry from ${name}`)
    const body = encodeURIComponent(`Hello RightStepConsultant,\n\nMy name is ${name}. I am interested in ${interest}.\n\nPlease contact me with the next steps.`)
    window.location.href = `mailto:${EMAIL}?subject=${subject}&body=${body}`
    setModal(null)
    setToast('Your enquiry is ready to send. We’ll help with the next right step.')
    window.setTimeout(() => setToast(''), 4200)
  }

  return (
    <div className="site-shell">
      <div className="page-frame">
        <header className="site-header">
          <a className="wordmark" href="#home" onClick={(e) => { e.preventDefault(); scrollTo('home') }}>
            <span className="wordmark-mark"><span /><span /></span>
            <span>RightStep<span className="wordmark-light">Consultant</span></span>
          </a>
          <nav className={`main-nav ${menuOpen ? 'is-open' : ''}`} aria-label="Primary navigation">
            {navItems.map((item) => <a key={item.id} className={activeSection === item.id ? 'active' : ''} href={`#${item.id}`} onClick={(e) => { e.preventDefault(); scrollTo(item.id) }}>{item.label}</a>)}
            <button className="header-apply" onClick={() => setModal('apply')}>Apply now <ArrowUpRight size={14} /></button>
          </nav>
          <button className="mobile-menu" onClick={() => setMenuOpen(!menuOpen)} aria-label="Toggle navigation">{menuOpen ? <X size={20} /> : <Menu size={20} />}</button>
        </header>

        <main>
          <section className="template-hero" id="home">
            <div className="hero-backdrop" />
            <div className="hero-topline"><span className="brand-lockup"><span className="brand-symbol">✦</span> RightStep</span><span>Overseas careers & education</span></div>
            <div className="hero-inner">
              <div className="hero-copy">
                <div className="eyebrow"><span className="lime-dot" /> Global opportunity, made clearer</div>
                <h1>Trusted guidance<br />for your <span>next chapter.</span></h1>
                <p>Your Future Starts with the Right step. We help you find the right career opportunities, access quality education, and navigate international opportunities with confidence.</p>
                <div className="hero-actions"><button className="button button-primary" onClick={() => setModal('apply')}>Apply now <ArrowUpRight size={16} /></button><a className="hero-link" href="#immigration" onClick={(e) => { e.preventDefault(); scrollTo('immigration') }}>Explore our pathways <ArrowRight size={15} /></a></div>
              </div>
            </div>
            <div className="hero-partners"><span>RIGHTSTEP / 2026</span><div className="partner-list"><span><ShieldCheck size={12} /> Guidance first</span><span><Globe2 size={12} /> Global reach</span><span><Check size={12} /> Clear next steps</span><span><Star size={12} /> Rated support</span></div></div>
          </section>

          <section className="light-section intro-section" aria-label="About our consultancy">
            <div className="section-marker"><span className="lime-dot" /> WHAT WE DO</div>
            <div className="intro-grid"><h2>We work with<br />ambitious people<br />who are navigating<br /><span>the next big move.</span></h2><div className="intro-copy"><p>RightStepConsultant helps individuals turn international ambition into a practical plan. We combine professional recruitment and education guidance with personal attention at every stage.</p><p>Whether you are choosing a country, a course, or a career route, our job is to make the right step feel clearer.</p><a className="dark-link" href="#about" onClick={(e) => { e.preventDefault(); scrollTo('about') }}>More about RightStep <ArrowRight size={15} /></a></div></div>
            <div className="metric-grid"><div><Globe2 size={16} /><strong>04</strong><span>Destination pathways<br />to explore</span></div><div><ShieldCheck size={16} /><strong>01</strong><span>Personal plan<br />for every profile</span></div><div><Star size={16} /><strong>5/5</strong><span>Professional<br />support mindset</span></div></div>
          </section>

          <section className="dark-section services-section" id="immigration">
            <div className="section-marker light-marker"><span className="lime-dot" /> IMMIGRATION & RECRUITMENT</div>
            <div className="services-grid"><div className="services-copy"><h2>Strategic support<br /><span>for your move.</span></h2><p>International opportunities deserve more than a quick answer. We help you understand the route, prepare with confidence, and keep moving.</p><button className="dark-button" onClick={() => setModal('apply')}>View all services <ArrowRight size={15} /></button></div><div className="service-rail"><article className="service-card service-card-image"><div className="service-image image-one" /><span className="service-label">01 / Overseas jobs</span><h3>Work abroad<br /><em>with clarity.</em></h3><p>Find the role and route that align with your experience and ambition.</p></article><article className="service-card service-card-image"><div className="service-image image-two" /><span className="service-label">02 / Education</span><h3>Study with<br /><em>purpose.</em></h3><p>Choose a course and country that open doors for the future you want.</p></article><article className="service-card service-card-image"><div className="service-image image-three" /><span className="service-label">03 / Planning</span><h3>Plan your<br /><em>next chapter.</em></h3><p>Build a practical path through applications, documents, and decisions.</p></article></div></div>
            <div className="service-rule"><span /> <small>Scroll to explore pathways</small></div>
          </section>

          <section className="light-section countries-section" id="countries">
            <div className="section-marker"><span className="lime-dot" /> COUNTRIES</div>
            <div className="countries-head"><h2>The right place<br /><span>changes perspective.</span></h2><p>Compare the pathways we help future-builders explore, then talk to us about which one fits your goals.</p></div>
            <div className="country-list">{countries.map((country, index) => <a href="#about" onClick={(e) => { e.preventDefault(); scrollTo('about') }} className="country-row" key={country.code}><span className="country-number">0{index + 1}</span><span className="country-code">{country.code}</span><strong>{country.name}</strong><small>{country.type}</small><ArrowUpRight size={17} /></a>)}</div>
          </section>

          <section className="light-section approach-section" id="education">
            <div className="section-marker centered-marker"><span className="lime-dot" /> EDUCATION PATHWAYS</div>
            <div className="approach-heading"><h2>Our guidance<br /><span>approach.</span></h2><p>Clear thinking for an important decision — tailored to your profile, your timing, and your definition of success.</p></div>
            <div className="approach-grid"><div className="approach-image"><div className="approach-image-label">RIGHTSTEP / METHOD</div></div><div className="approach-list"><div className="approach-item active"><span>01</span><div><h3>Discover</h3><p>We understand where you are now and what you want your next chapter to look like.</p></div><Check size={16} /></div><div className="approach-item"><span>02</span><div><h3>Design</h3><p>We shape the country, course, or career route around your strengths and goals.</p></div><Check size={16} /></div><div className="approach-item"><span>03</span><div><h3>Move forward</h3><p>We stay close through applications, documentation, and every next right step.</p></div><ArrowUpRight size={16} /></div></div></div>
          </section>

          <section className="dark-section about-section" id="about">
            <div className="section-marker light-marker"><span className="lime-dot" /> ABOUT RIGHTSTEP</div>
            <div className="about-grid"><div><h2>Your future deserves<br /><span>the right support.</span></h2></div><div><p>Led by Sumanth Kolanti, RightStepConsultant exists to make global opportunity more human, more practical, and more personal.</p><p>We listen carefully, advise honestly, and help you take the next right step with confidence.</p><div className="about-actions"><a className="dark-button light-button" href={WHATSAPP} target="_blank" rel="noreferrer"><MessageCircle size={16} /> WhatsApp us</a><a className="light-link" href={`tel:${PHONE}`}><Phone size={15} /> +91 {PHONE}</a></div></div></div>
          </section>
        </main>

        <footer className="site-footer"><div className="footer-brand"><a className="wordmark" href="#home" onClick={(e) => { e.preventDefault(); scrollTo('home') }}><span className="wordmark-mark"><span /><span /></span><span>RightStep<span className="wordmark-light">Consultant</span></span></a><span>Overseas job recruitment<br />& education consultancy.</span></div><div className="footer-links"><a href={`mailto:${EMAIL}`}>{EMAIL}</a><a href="#terms" onClick={(e) => { e.preventDefault(); setModal('terms') }}>Terms</a><a href="#privacy" onClick={(e) => { e.preventDefault(); setModal('privacy') }}>Privacy</a></div><div className="footer-bottom"><span>© 2026 RightStepConsultant</span><span>Built for your next chapter <span className="lime-dot" /></span></div></footer>
      </div>
      {modal && <Modal type={modal} onClose={() => setModal(null)} onSubmit={handleApply} />}
      {toast && <div className="toast"><Check size={15} /> {toast}<button onClick={() => setToast('')}><X size={14} /></button></div>}
    </div>
  )
}

function Modal({ type, onClose, onSubmit }) {
  const title = type === 'apply' ? 'Start with a conversation.' : type === 'terms' ? 'Terms of use.' : 'Privacy, plainly put.'
  return <div className="modal-backdrop" onMouseDown={(e) => { if (e.target === e.currentTarget) onClose() }}><div className="modal-card"><button className="modal-close" onClick={onClose} aria-label="Close"><X size={18} /></button><div className="section-marker"><span className="lime-dot" /> RIGHTSTEPCONSULTANT</div><h2>{title}</h2>{type === 'apply' ? <><p>Tell us what you are exploring and we’ll reply at <strong>{EMAIL}</strong> with a thoughtful first step.</p><form onSubmit={onSubmit}><label>Name<input name="name" required placeholder="Your full name" /></label><label>What are you exploring?<select name="interest" defaultValue="" required><option value="" disabled>Select one</option><option>Overseas work opportunities</option><option>International education</option><option>Country and pathway guidance</option><option>I’m still figuring it out</option></select></label><label>Message <small>optional</small><textarea name="message" rows="3" placeholder="Tell us what’s on your mind" /></label><button className="button button-primary full-button">Send my enquiry <ArrowUpRight size={16} /></button></form></> : <div className="legal-copy"><p><strong>Last updated: 7 November 2026</strong></p><p>{type === 'terms' ? 'RightStepConsultant provides general guidance for overseas recruitment, education, and international mobility. Guidance is not a guarantee of admission, employment, visa approval, or a particular outcome.' : 'We collect only the details you choose to share when contacting RightStepConsultant, such as your name, email address, phone number, interests, and message. We use this information to respond to your enquiry.'}</p><h3>{type === 'terms' ? 'Your responsibility' : 'How we handle it'}</h3><p>{type === 'terms' ? 'You remain responsible for reviewing the requirements and official terms of any employer, institution, government, or third-party service you engage with.' : `Your information is used for communication related to your request. We do not sell your personal information. Contact ${EMAIL} to ask a question or request an update.`}</p></div>}</div></div>
}

createRoot(document.getElementById('root')).render(<App />)
