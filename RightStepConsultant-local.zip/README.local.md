# RightStepConsultant — Local Build

## Requirements

- Node.js 18+ (Node.js 20+ recommended)
- npm 9+

## Run locally

```bash
npm install
npm run dev
```

Open the local URL shown by Vite, normally `http://localhost:3000`.

## Create a production build

```bash
npm run build
npm run preview -- --host 0.0.0.0 --port 3000
```

All website images used by the design are stored locally in `public/images/`. The original visual reference is included in `reference/` for design context. No image download is required to run the site.
